//
//  CommentViewController.swift
//  MyArticlesapp
//
//  Created by Nivedha Moorthy on 10/03/25.
//

import UIKit

class CommentViewController: UIViewController {
    
    @IBOutlet weak var commentBox: UITextField!
    @IBOutlet weak var sendbtn: UIButton!
    
    var articleId: String?
    var apiService = APIService()
    var onCommentAdded: ((String) -> Void)?
    override func viewDidLoad() {
        super.viewDidLoad()
        
        setupUI()
    }
    private func setupUI() {
        
        sendbtn.layer.cornerRadius = 8
        sendbtn.backgroundColor = .clear
        sendbtn.setTitleColor(.white, for: .normal)
        commentBox.layer.borderColor = UIColor.gray.cgColor
        commentBox.layer.borderWidth = 0.5
        sendbtn.addTarget(self, action: #selector(didTapSubmit), for: .touchUpInside)
    }
    @objc private func didTapSubmit() {
        
        guard let commentText = commentBox.text, !commentText.isEmpty else {
            showAlert("Comment cannot be empty")
            return
        }
        guard let articleId = articleId else { return }
        var currentComments = CoreDataManager.shared.fetchCommentsCount(for: articleId)
        currentComments += 1
        CoreDataManager.shared.saveCommentsCount(for: articleId, count: currentComments)
        self.onCommentAdded?(commentText)
        self.dismiss(animated: true)
    }
}
