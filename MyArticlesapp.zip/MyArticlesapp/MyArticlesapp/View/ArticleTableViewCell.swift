//
//  ArticleTableViewCell.swift
//  MyArticlesapp
//
//  Created by Nivedha Moorthy on 09/03/25.
//

import UIKit

class ArticleTableViewCell: UITableViewCell {
    
    @IBOutlet weak var articleImageView: UIImageView!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
        self.layer.cornerRadius = 10
        self.layer.masksToBounds = true
        self.layer.borderWidth = 1
        self.layer.borderColor = UIColor.lightGray.cgColor
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
    private var imageURL: URL?
    
    func configure(with article: ArticleDetails) {
        titleLabel.text = article.title
        authorLabel.text = article.author ?? "No Author"
        dateLabel.text = article.publishedAt?.formattedDate() ?? ""
        descriptionLabel.text = article.description ?? ""
        authorLabel.numberOfLines = 0
        authorLabel.lineBreakMode = .byWordWrapping
        titleLabel.numberOfLines = 0
        titleLabel.lineBreakMode = .byWordWrapping
        descriptionLabel.numberOfLines = 0
        titleLabel.setContentCompressionResistancePriority(.defaultHigh, for: .vertical)
        descriptionLabel.lineBreakMode = .byWordWrapping
        articleImageView.contentMode = .scaleAspectFill
        articleImageView.clipsToBounds = true
        articleImageView.image = UIImage(named: "placeholder")
        if let imageUrl = article.urlToImage, let url = URL(string: imageUrl) {
            if imageUrl.hasSuffix(".webp") {
                return
            }
            articleImageView.loadImage(from: url)
        }
    }
    
}
