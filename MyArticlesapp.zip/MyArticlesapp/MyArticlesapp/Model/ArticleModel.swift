//
//  ArticleModel.swift
//  MyArticlesapp
//
//  Created by Nivedha Moorthy on 08/03/25.
//

import Foundation

struct ArticleModel : Codable {
    let status : String?
    let totalResults : Int?
    let articles : [ArticleDetails]?
}
struct ArticleDetails : Codable {
    let source : Source?
    let author : String?
    let title : String?
    let description : String?
    let url : String?
    let urlToImage : String?
    let publishedAt : String?
    let content : String?
}
struct Source : Codable {
    let id : String?
    let name : String?
}
