//
//  CoreDataManager.swift
//  MyArticlesapp
//
//  Created by Nivedha Moorthy on 08/03/25.
//

import CoreData
import UIKit

class CoreDataManager {
    
    static let shared = CoreDataManager()
    
    let persistentContainer: NSPersistentContainer
    
    private init() {
        persistentContainer = NSPersistentContainer(name: "MyArticlesapp")
        persistentContainer.loadPersistentStores { (storeDescription, error) in
            if let error = error {
                fatalError("Unresolved error \(error)")
            }
        }
    }
    var context: NSManagedObjectContext {
        return persistentContainer.viewContext
    }
    
    func saveLikeState(for articleId: String, isLiked: Bool, count: Int) {
        let context = CoreDataManager.shared.context
        let fetchRequest: NSFetchRequest<Article_app> = Article_app.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", articleId)
        
        do {
            if let article = try context.fetch(fetchRequest).first {
                article.likesCount = Int16(count)
                article.isLiked = isLiked
            } else {
                let newArticle = Article_app(context: context)
                newArticle.id = articleId
                newArticle.likesCount = Int16(count)
                newArticle.isLiked = isLiked
            }
            try context.save()
        } catch {
            print("Failed to save like state: \(error)")
        }
    }
    
    func fetchLikeState(for articleId: String) -> (isLiked: Bool, likesCount: Int) {
        let context = CoreDataManager.shared.context
        let fetchRequest: NSFetchRequest<Article_app> = Article_app.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", articleId)
        
        do {
            if let article = try context.fetch(fetchRequest).first {
                return (article.isLiked, Int(article.likesCount))
            }
        } catch {
            print("Failed to fetch like state: \(error)")
        }
        return (false, 0)
    }
    
    func saveCommentsCount(for articleId: String, count: Int) {
        let context = CoreDataManager.shared.context
        let fetchRequest: NSFetchRequest<Article_app> = Article_app.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", articleId)
        
        do {
            if let article = try context.fetch(fetchRequest).first {
                article.commentsCount = Int16(count)
            } else {
                let newArticle = Article_app(context: context)
                newArticle.id = articleId
                newArticle.commentsCount = Int16(count)
            }
            try context.save()
        } catch {
            print("Failed to save comments count: \(error)")
        }
    }
    
    func fetchCommentsCount(for articleId: String) -> Int {
        let context = CoreDataManager.shared.context
        let fetchRequest: NSFetchRequest<Article_app> = Article_app.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", articleId)
        
        do {
            if let article = try context.fetch(fetchRequest).first {
                return Int(article.commentsCount)
            }
        } catch {
            print("Failed to fetch comments count: \(error)")
        }
        return 0
    }
    
    func saveBookmarkState(for articleId: String, isBookmarked: Bool) {
        let context = CoreDataManager.shared.context
        let fetchRequest: NSFetchRequest<Article_app> = Article_app.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", articleId)
        
        do {
            if let article = try context.fetch(fetchRequest).first {
                article.isBookmarked = isBookmarked
            } else {
                let newArticle = Article_app(context: context)
                newArticle.id = articleId
                newArticle.isBookmarked = isBookmarked
            }
            try context.save()
            print("Bookmark state saved: \(isBookmarked) for \(articleId)")
        } catch {
            print("Failed to save bookmark state: \(error)")
        }
    }
    
    func fetchBookmarkState(for articleId: String) -> Bool {
        let context = CoreDataManager.shared.context
        let fetchRequest: NSFetchRequest<Article_app> = Article_app.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "id == %@", articleId)
        
        do {
            if let article = try context.fetch(fetchRequest).first {
                print("Fetched bookmark state: \(article.isBookmarked) for \(articleId)")
                return article.isBookmarked
            }
        } catch {
            print("Failed to fetch bookmark state: \(error)")
        }
        return false // Default to not bookmarked
    }
    
}
