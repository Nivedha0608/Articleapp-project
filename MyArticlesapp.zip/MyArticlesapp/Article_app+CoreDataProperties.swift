//
//  Article_app+CoreDataProperties.swift
//  
//
//  Created by Nivedha Moorthy on 09/03/25.
//
//

import Foundation
import CoreData


extension Article_app {

    @nonobjc public class func fetchRequest() -> NSFetchRequest<Article_app> {
        return NSFetchRequest<Article_app>(entityName: "Article_app")
    }

    @NSManaged public var title: String?
    @NSManaged public var author: String?
    @NSManaged public var urlToImage: String?
    @NSManaged public var publishedAt: String?
    @NSManaged public var content: String?
    @NSManaged public var url: String?

}
