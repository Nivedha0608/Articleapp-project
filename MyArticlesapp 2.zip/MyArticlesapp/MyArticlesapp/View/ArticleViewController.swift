//
//  ArticleViewController.swift
//  MyArticlesapp
//
//  Created by Nivedha Moorthy on 08/03/25.
//

import UIKit

class ArticleViewController: UIViewController {
    
    @IBOutlet weak var articleTableview: UITableView!
    private var viewModel = ArticleViewModel()
    private let refreshControl = UIRefreshControl()
    private let loadingIndicator = UIActivityIndicatorView(style: .large)

    override func viewDidLoad() {
        super.viewDidLoad()
        setupTableView()
        setupLoadingIndicator()
        refreshControl.addTarget(self, action: #selector(refreshData), for: .valueChanged)
        articleTableview.addSubview(refreshControl)
        viewModel.onDataUpdated = { [weak self] in
            DispatchQueue.main.async {
                print("Reloading table with \(self?.viewModel.numberOfArticles() ?? 0) articles")
                self?.loadingIndicator.stopAnimating()
                self?.articleTableview.reloadData()
                self?.refreshControl.endRefreshing()
            }
        }
        viewModel.fetchArticles()
        loadingIndicator.startAnimating()
    }
    
    func setupLoadingIndicator() {
        loadingIndicator.center = view.center
        view.addSubview(loadingIndicator)
    }
    
    func setupTableView() {
        articleTableview.register(UINib(nibName: "ArticleTableViewCell", bundle: nil), forCellReuseIdentifier: "ArticleTableViewCell")
        articleTableview.delegate = self
        articleTableview.dataSource = self
        articleTableview.separatorStyle = .none
    }
    @objc func refreshData() {
        print("Refreshing articles...")
        viewModel.fetchArticles(isInitialLoad: true)
    }
    
}
extension ArticleViewController: UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print("Articles Count: \(viewModel.numberOfArticles())")
        return viewModel.numberOfArticles()
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        if indexPath.row == viewModel.numberOfArticles() - 1, viewModel.isFetching {
            let cell = UITableViewCell()
            let activityIndicator = UIActivityIndicatorView(style: .medium)
            activityIndicator.startAnimating()
            activityIndicator.center = cell.contentView.center
            cell.contentView.addSubview(activityIndicator)
            return cell
        }
        
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ArticleTableViewCell", for: indexPath) as? ArticleTableViewCell else {
            return UITableViewCell()
        }
        
        if let article = viewModel.getArticle(at: indexPath.row) {
            cell.configure(with: article)
        } else {
            
        }
        
        return cell
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return UITableView.automaticDimension
    }
    func tableView(_ tableView: UITableView, willDisplay cell: UITableViewCell, forRowAt indexPath: IndexPath) {
        cell.layer.cornerRadius = 12
        cell.layer.masksToBounds = true
        cell.clipsToBounds = true
        cell.contentView.layer.masksToBounds = true
        cell.contentView.layer.cornerRadius = 12
        cell.contentView.layer.borderWidth = 1
        cell.contentView.layer.borderColor = UIColor.lightGray.cgColor
    }
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let offsetY = scrollView.contentOffset.y
        let contentHeight = scrollView.contentSize.height
        let tableViewHeight = scrollView.frame.size.height
        if offsetY > contentHeight - tableViewHeight - 200 {
            viewModel.fetchArticles(isInitialLoad: false)
        }
    }
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        if let selectedArticle = viewModel.getArticle(at: indexPath.row) {
            navigateToArticleDetailViewController(with: selectedArticle)
        } else {
            print("Article not found")
        }
    }
    func navigateToArticleDetailViewController(with article: ArticleDetails) {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let detailVC = storyboard.instantiateViewController(withIdentifier: "ArticleDetailViewController") as? ArticleDetailViewController {
            detailVC.article = article
            navigationController?.pushViewController(detailVC, animated: true)
        }
    }
}
