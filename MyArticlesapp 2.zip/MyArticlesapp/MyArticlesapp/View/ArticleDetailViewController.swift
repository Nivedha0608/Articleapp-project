//
//  ArticleDetailViewController.swift
//  MyArticlesapp
//
//  Created by Nivedha Moorthy on 09/03/25.
//

import UIKit

class ArticleDetailViewController: UIViewController {
    
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var authorLabel: UILabel!
    @IBOutlet weak var dateLabel: UILabel!
    @IBOutlet weak var contentTextView: UITextView!
    @IBOutlet var detailimageview: UIImageView!
    @IBOutlet weak var likebtn: UIButton!
    @IBOutlet weak var commentbtn: UIButton!
    @IBOutlet weak var unlikebtn: UIButton!
    @IBOutlet weak var bookmarkbtn: UIButton!
    @IBOutlet weak var backbtn: UIButton!
    @IBOutlet weak var articleScrollview: UIScrollView!
    @IBOutlet weak var articlecontentview: UIView!
    @IBOutlet weak var likesLabel: UILabel!
    @IBOutlet weak var UnlikeLabel: UILabel!
    @IBOutlet weak var commentsLabel: UILabel!
    var article: ArticleDetails?
    var textComponents: [String] = []
    private let viewModel = ArticleViewModel()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        setup()
        setupArticleDetails()
        backbtn.setImage(UIImage(named: "backarrow"), for: .normal)
        backbtn.addTarget(self, action: #selector(didTapBackButton), for: .touchUpInside)
    }
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        articleScrollview.isScrollEnabled = true
    }
    @objc func didTapBackButton() {
        // Navigate back manually
        navigationController?.popViewController(animated: true)
    }
    private func setup() {
        viewModel.likesCount = { [weak self] likes in
            self?.likesLabel.text = "\(likes)"
        }
        viewModel.commentsCount = { [weak self] comments in
            self?.commentsLabel.text = "\(comments)"
            
        }
    }
    
    private func setupArticleDetails() {
        guard let article = article else { return }
        
        titleLabel.text = article.title
        authorLabel.text = ("By \(article.author ?? "No Author")")
        if let imageUrlString = article.urlToImage, let imageUrl = URL(string: imageUrlString) {
            detailimageview.loadImage(from: imageUrl)
        }
        dateLabel.text = article.publishedAt?.formattedDate(includeTime: true) ?? "Unknown Date"
        detailimageview.contentMode = .scaleAspectFill
        detailimageview.clipsToBounds = true
        let content = article.content ?? ""
        let description = article.description ?? ""
        let urlString = article.url ?? ""
        let fullText = "\(content)\(description)\n\(urlString)"
        let attributedString = NSMutableAttributedString(string: fullText)
        if let urlRange = fullText.range(of: urlString) {
            let nsRange = NSRange(urlRange, in: fullText)
            attributedString.addAttribute(.link, value: urlString, range: nsRange)
            attributedString.addAttribute(.underlineStyle, value: NSUnderlineStyle.single.rawValue, range: nsRange)
        }
        contentTextView.attributedText = attributedString
        contentTextView.isEditable = false
        contentTextView.isSelectable = true
        contentTextView.dataDetectorTypes = .link
        contentTextView.textColor = .white
        contentTextView.translatesAutoresizingMaskIntoConstraints = false
        contentTextView.alwaysBounceVertical = true
        let articleId = article.source?.id ?? article.source?.name ?? ""
        let (isLiked, likesCount) = CoreDataManager.shared.fetchLikeState(for: articleId)
        likebtn.setImage(UIImage(systemName: isLiked ? "hand.thumbsup.fill" : "hand.thumbsup"), for: .normal)
        likesLabel.text = "\(likesCount)"
        let commentsCount = CoreDataManager.shared.fetchCommentsCount(for: articleId)
        commentsLabel.text = "\(commentsCount)"
        let storedComments = CoreDataManager.shared.fetchCommentsCount(for: article.source?.id ?? "")
        commentsLabel.text = "\(storedComments)"
        let isBookmarked = CoreDataManager.shared.fetchBookmarkState(for: article.source?.id ?? "")
        bookmarkbtn.setImage(UIImage(systemName: isBookmarked ? "bookmark.fill" : "bookmark"), for: .normal)
        bookmarkbtn.addTarget(self, action: #selector(didTapBookmark), for: .touchUpInside)
        likebtn.addTarget(self, action: #selector(didTapLike), for: .touchUpInside)
        commentbtn.setImage(UIImage(systemName: "message"), for: .normal)
        commentbtn.tintColor = .white
        commentbtn.isUserInteractionEnabled = true
        commentbtn.addTarget(self, action: #selector(didTapComment), for: .touchUpInside)
        
        
    }
    @objc func didTapComment() {
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        if let commentVC = storyboard.instantiateViewController(withIdentifier: "CommentViewController") as? CommentViewController {
            commentVC.articleId = ("\(String(describing: article?.source?.id))\(String(describing: article?.source?.name))")
            
            commentVC.onCommentAdded = { [weak self] comment in
                guard let self = self, let articleId = self.article?.source?.id else { return }
                
                var currentComments = CoreDataManager.shared.fetchCommentsCount(for: articleId)
                currentComments += 1
                CoreDataManager.shared.saveCommentsCount(for: articleId, count: currentComments)
                DispatchQueue.main.async {
                    self.commentsLabel.text = "\(currentComments)"
                }
            }
            if let sheet = commentVC.sheetPresentationController {
                sheet.detents = [.medium(), .large()]
                sheet.detents = [
                        .custom(resolver: { context in 200 }) 
                    ]
                sheet.prefersGrabberVisible = true
            }
            present(commentVC, animated: true)
        }
    }
    
    @objc func didTapLike() {
        guard let articleId = article?.source?.id ?? article?.source?.name, !articleId.isEmpty else {
            print("Article ID not found")
            return
        }
        var (isLiked, likesCount) = CoreDataManager.shared.fetchLikeState(for: articleId)
        if isLiked {
            likesCount = max(likesCount - 1, 0)
            likebtn.setImage(UIImage(systemName: "hand.thumbsup"), for: .normal)
        } else {
            likesCount += 1
            likebtn.setImage(UIImage(systemName: "hand.thumbsup.fill"), for: .normal)
        }
        CoreDataManager.shared.saveLikeState(for: articleId, isLiked: !isLiked, count: likesCount)
        likesLabel.text = "\(likesCount)"
    }
    
    @objc func didTapBookmark() {
        guard let articleId = article?.source?.id else { return }
        let isCurrentlyBookmarked = CoreDataManager.shared.fetchBookmarkState(for: articleId)
        let newBookmarkState = !isCurrentlyBookmarked
        CoreDataManager.shared.saveBookmarkState(for: articleId, isBookmarked: newBookmarkState)
        bookmarkbtn.setImage(UIImage(systemName: newBookmarkState ? "bookmark.fill" : "bookmark"), for: .normal)
    }
}
