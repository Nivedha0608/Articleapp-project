//
//  UIViewController+Extensions.swift
//  MyArticlesapp
//
//  Created by Nivedha Moorthy on 08/03/25.
//

import UIKit

extension UIViewController {
    
    func showAlert( _ message: String ) {
        let alert = UIAlertController(title: "", message: message, preferredStyle: .alert)
        alert.addAction( UIAlertAction(title: "Ok", style: .cancel, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }
    
}
extension UIImageView {
    func loadImage(from url: URL) {
        DispatchQueue.global(qos: .background).async {
            if let data = try? Data(contentsOf: url), let image = UIImage(data: data) {
                DispatchQueue.main.async {
                    self.image = image
                }
            } else {
                DispatchQueue.main.async {
                    self.image = UIImage(named: "placeholder") // Fallback image
                }
            }
        }
    }
}
extension String {
    func formattedDate(includeTime: Bool = false) -> String {
        let inputFormatter = DateFormatter()
        inputFormatter.dateFormat = "yyyy-MM-dd'T'HH:mm:ssZ" // Match API format
        inputFormatter.locale = Locale(identifier: "en_US_POSIX")
        
        guard let date = inputFormatter.date(from: self) else {
            return "Unknown Date"
        }
        
        let outputFormatter = DateFormatter()
        outputFormatter.dateFormat = includeTime ? "MMMM d, yyyy - h:mm a" : "MMMM d, yyyy"
        
        return outputFormatter.string(from: date)
    }
}
