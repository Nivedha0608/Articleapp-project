//
//  ArticleViewModel.swift
//  MyArticlesapp
//
//  Created by Nivedha Moorthy on 08/03/25.
//

import Foundation

class ArticleViewModel {
    
    private let apiService = APIService()
    private let coreDataManager = CoreDataManager.shared // Use Singleton
    private var currentPage = 1
    private let pageSize = 20
    var isFetching = false
    var likesCount: ((Int) -> Void)?
    var commentsCount: ((Int) -> Void)?
    private var currentLikes = 0
    var isLiked = false
    var articles: [ArticleDetails] = []
    
    var onDataUpdated: (() -> Void)?
    
    func fetchArticles(isInitialLoad: Bool = true) {
        guard !isFetching else { return }
        isFetching = true
        
        if isInitialLoad {
            currentPage = 1
            articles.removeAll()
        }
        
        apiService.fetchNews(page: currentPage, pageSize: pageSize) { [weak self] result in
            guard let self = self else { return }
            self.isFetching = false
            
            switch result {
            case .success(let fetchedArticles):
                self.articles.append(contentsOf: fetchedArticles)
                self.currentPage += 1 // Move to next page
                
                DispatchQueue.main.async {
                    self.onDataUpdated?()
                }
            case .failure(let error):
                print("Error fetching articles: \(error.localizedDescription)")
            }
        }
    }
    
    func fetchLikes(for articleId: String) {
        apiService.fetchLikes(for: articleId) { [weak self] likes in
            DispatchQueue.main.async {
                self?.currentLikes = likes ?? 0
                self?.likesCount?(self?.currentLikes ?? 0)
            }
        }
    }
    
    func fetchComments(for articleId: String) {
        
        
        apiService.fetchComments(for: articleId) { [weak self] comments in
            DispatchQueue.main.async {
                self?.commentsCount?(comments ?? 0)
            }
        }
    }
    func toggleLike() {
        isLiked.toggle()
        currentLikes += isLiked ? 1 : -1
        currentLikes = max(0, currentLikes)
        likesCount?(currentLikes)
    }
    
    func numberOfArticles() -> Int {
        return articles.count
    }
    
    func getArticle(at index: Int) -> ArticleDetails? {
        guard index >= 0 && index < articles.count else {
            return nil
        }
        return articles[index]
    }
}
