//
//  Article_app+CoreDataClass.swift
//  
//
//  Created by Nivedha Moorthy on 09/03/25.
//
//

import Foundation
import CoreData

@objc(Article_app)
public class Article_app: NSManagedObject {

}
