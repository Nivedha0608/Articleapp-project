//
//  MyArticlesappTests.swift
//  MyArticlesappTests
//
//  Created by Nivedha Moorthy on 08/03/25.
//

import Testing
@testable import MyArticlesapp

struct MyArticlesappTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
